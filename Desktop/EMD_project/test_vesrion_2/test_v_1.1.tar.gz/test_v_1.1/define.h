#include <string>
#ifndef DEFINE_H
#define DEFINE_H


//Default Values
extern int change_phase=0;
//purser parameters
extern int start_reading=800; //the columm that will start to pass data of ECG
extern int L_data2=250; //the number of the data of ECG
extern const int L=L_data2;
extern const int L_data=250;
extern std::string ECG_data= "/home/mamalakis/EMD_project/data/experimental/filtered.txt"; //path of ECG file

// B_spline parameters
extern int N_sample2=250;//b_spline interpolation namber
extern const int N=N_sample2;
extern const int N_sample=250;
extern double increase_value=0.01;//the number of stadar deviation for the extrema where left the signal out of the interpolation max/min boundaries
extern double cub_coef_a= 1.0000/6.0000 ;//default 1/6
extern double cub_coef_b= 2.0000/3.0000 ;//default 2/3
extern double cub_coef_c= 1.0000/2.0000 ;//default 1/2
extern int type_interpolation= 1 ;//linear (1), cubic_spline (0)

// external loop detection 
extern int MAX_LOOP= 20 ;// IMF max number extrema detection rule depentend

//extrema define parameters
extern const int POINTS_OF_EVAL= 2 ;//point of slope evaluation
extern std::string PATH_OF_TXT= "/home/mamalakis/Desktop/test.txt"; //path for store the extrema txt number I have to remove it
extern double ACCUR= 0.0001 ;// the accurate which determine the extrema critirio IMF extract stop depends the scale of signal measurement
extern int Critirio= 1;// the critirio (1) is the absolute difference of min-max for all the extrema lower from ACCUR, the critirio (2) is the mean value <ACCUR.=
#define variation 0.00000001;// the variance of the extremaof initial and final value of signal
//internal loop parameter 
extern int MAX_INTLOOP= 15 ;//maximun internal loops IMF SD<0.3
extern double SDif1= 0.5 ;//the upper limite of sum differences between the h computed
extern double SDif2= 0.2 ;//the down limite of sum differences between the h computed
//BW filter parameters
extern double FREQ= 0.8 ;// the low pass frequency cut
extern double M_FREQ= 20 ;// freq/M_FREQ^(k-1) portion of the FREQ change through the k IMF
extern double VAR_ACCUR= 0.00000002 ;//VARIANCE aacurance critirio VAR_k<VAR_ACCUR, VAR_k-1>VAR_ACCUR

//DEBUG////////////////////////////////////////////////////
#define DEBUG(x) cout << '>' << #x << ':' << x << endl;
///use DEBUG(value_need_to_check)//////////////////////

#endif
