////////////////////////////////////////////////////////////////////////////////////

//Copyright (C) 2017 Michail Mamalakis

//Author: Michail Mamalakis <mixalis.mamalakis@gmail.com>
//Maintainer: Michail Mamalakis <mixalis.mamalakis@gmail.com>
//Keywords: Implementation ECG filters
//Version: 0.3

//////////////////////////////////////////////////////////////////////////////////


#include <string>
#ifndef DEFINE_H
#define DEFINE_H


#define variation 0.00000001;
extern int change_phase_lock;
extern int start_reading; 
extern int L_data2; 
extern const int L_data=250;
extern std::string ECG_data;
// B_spline parameters
extern int N_sample2;
extern const int N_sample=250;
extern double increase_value;
extern double cub_coef_a;
extern double cub_coef_b;
extern double cub_coef_c;
extern int type_interpolation;
extern int MAX_LOOP;
//extrema define parameters
extern const int POINTS_OF_EVAL=2;
extern std::string PATH_OF_TXT; 
extern double ACCUR;
extern int Critirio; 
//internal loop parameter 
extern int MAX_INTLOOP;
extern double SDif1;
extern double SDif2;
//BW filter parameters
extern double FREQ;
extern double M_FREQ;
extern double VAR_ACCUR;



//DEBUG////////////////////////////////////////////////////
#define DEBUG(x) cout << '>' << #x << ':' << x << endl;
///use DEBUG(value_need_to_check)//////////////////////

#endif
