////////////////////////////////////////////////////////////////////////////////////

//Copyright (C) 2017 Michail Mamalakis

//Author: Michail Mamalakis <mixalis.mamalakis@gmail.com>
//Maintainer: Michail Mamalakis <mixalis.mamalakis@gmail.com>
//Keywords: Implementation ECG filters
//Version: 0.3

//////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////

//Copyright (C) 2017 Michail Mamalakis

//Author: Michail Mamalakis <mixalis.mamalakis@gmail.com>
//Maintainer: Michail Mamalakis <mixalis.mamalakis@gmail.com>
//Keywords: Implementation ECG filters
//Version: 0.3

//////////////////////////////////////////////////////////////////////////////////



#include <string>

 int change_phase_lock;
 int start_reading; 
 int L_data2; 
 const int L_data=250;
 std::string ECG_data;
// B_spline parameters
 int N_sample2;
 const int N_sample=250;
 double increase_value;
 double cub_coef_a;
 double cub_coef_b;
 double cub_coef_c;
 int type_interpolation;
 int MAX_LOOP;
//extrema define parameters
 int POINTS_OF_EVAL=2;
 std::string PATH_OF_TXT; 
 double ACCUR;
 int Critirio; 
//internal loop parameter 
 int MAX_INTLOOP;
 double SDif1;
 double SDif2;
//BW filter parameters
 double FREQ;
 double M_FREQ;
 double VAR_ACCUR;





